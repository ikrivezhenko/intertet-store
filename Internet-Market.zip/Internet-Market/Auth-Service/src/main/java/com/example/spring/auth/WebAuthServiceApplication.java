package com.example.spring.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebAuthServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(WebAuthServiceApplication.class, args);
    }
}